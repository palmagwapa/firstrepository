module.exports = function enableAuthentication(app) {
  // enable authentication
  app.enableAuth();
};
