This folder contains things relative to the bonfires' screens
